CREATE DATABASE IF NOT EXISTS peminjaman_db;
USE peminjaman_db;

-- Tabel User/Admin
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Tabel Peminjaman
CREATE TABLE IF NOT EXISTS peminjaman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_peminjam VARCHAR(100) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    jumlah INT NOT NULL,
    tgl_pinjam DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'Diproses'
);

-- Masukkan akun admin default (Username: admin, Password: admin123)
-- Password dienkripsi menggunakan password_hash() demi keamanan
INSERT INTO users (username, password) 
VALUES ('admin', '$2y$10$7rKMg8gR0L.nJy4yA1pYV.3B9H2K1v1e3f8g9h0i1j2k3l4m5n6o7p');
