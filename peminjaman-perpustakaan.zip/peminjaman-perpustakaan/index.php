<?php
session_start();

// Jika user sudah login sebelumnya, langsung alihkan ke dashboard
if (isset($_SESSION['login'])) {
    header("Location: dashboard.php");
    exit;
}

// Proses ketika tombol "Masuk" diklik
if (isset($_POST['submit_login'])) {
    // Mengambil inputan (apa pun yang diketik user)
    $username = $_POST['username'];
    
    // MEM-BYPASS VALIDASI: Membuat session login tanpa mengecek ke database
    $_SESSION['login'] = true;
    $_SESSION['username'] = htmlspecialchars($username); // Nama ini akan tampil di dashboard
    
    // Langsung lempar ke halaman utama
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Web Peminjaman</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background: #f4f6f9; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
        }
        .login-card { 
            background: #fff; 
            padding: 30px; 
            border-radius: 8px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.1); 
            width: 350px; 
        }
        h2 { 
            text-align: center; 
            margin-bottom: 5px; 
            color: #333; 
        }
        .subtitle {
            text-align: center;
            font-size: 12px;
            color: #777;
            margin-bottom: 25px;
        }
        .form-group { 
            margin-bottom: 15px; 
        }
        .form-group label { 
            display: block; 
            margin-bottom: 5px; 
            font-weight: bold; 
        }
        .form-group input { 
            width: 100%; 
            padding: 10px; 
            border: 1px solid #ccc; 
            border-radius: 4px; 
            box-sizing: border-box; 
        }
        button { 
            width: 100%; 
            padding: 12px; 
            background: #3498db; 
            border: none; 
            color: #fff; 
            font-weight: bold; 
            border-radius: 4px; 
            cursor: pointer; 
        }
        button:hover { 
            background: #2980b9; 
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>Login Sistem</h2>
        <div class="subtitle">(Mode Demo: Bisa pakai username & password apa saja)</div>
        
        <form action="" method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" required placeholder="Ketik nama bebas...">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Ketik sandi bebas...">
            </div>
            <button type="submit" name="submit_login">Masuk</button>
        </form>
    </div>
</body>
</html>
