<?php
session_start();
include 'koneksi.php';

// Proteksi halaman: jika belum login, kembalikan ke login.php
if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

// Proses Input Data Peminjaman
if (isset($_POST['submit_pinjam'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['peminjam']);
    $barang = mysqli_real_escape_string($koneksi, $_POST['barang']);
    $jumlah = intval($_POST['jumlah']);
    $tgl = $_POST['tglPinjam'];

    $query = "INSERT INTO peminjaman (nama_peminjam, nama_barang, jumlah, tgl_pinjam) VALUES ('$nama', '$barang', '$jumlah', '$tgl')";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Peminjaman berhasil disimpan!'); window.location='dashboard.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan data!');</script>";
    }
}

// Ambil data peminjaman dari database
$tampil_data = mysqli_query($koneksi, "SELECT * FROM peminjaman ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Peminjaman</title>
    <style>
        * { margin:0; padding:0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background: #f4f6f9; padding: 20px; }
        .container { max-width: 1100px; margin: 0 auto; }
        .header { background: #fff; padding: 15px 20px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .btn-logout { background: #e74c3c; color: #fff; padding: 8px 15px; text-decoration: none; border-radius: 4px; font-weight: bold; }
        .grid { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; }
        .card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        h3 { margin-bottom: 15px; color: #333; border-bottom: 2px solid #eee; padding-bottom: 5px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 14px; }
        .form-group input, .form-group select { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .btn-submit { width: 100%; padding: 10px; background: #2ecc71; border: none; color: #fff; font-weight: bold; border-radius: 4px; cursor: pointer; margin-top: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; font-size: 14px; }
        th { background: #f8f9fa; }
        .badge { padding: 4px 8px; background: #f39c12; color: #fff; border-radius: 4px; font-size: 12px; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2>Sistem Peminjaman Barang</h2>
        <div>
            <span>Selamat Datang, <strong><?php echo $_SESSION['username']; ?></strong>! </span>
            <a href="logout.php" class="btn-logout" onclick="return confirm('Yakin ingin keluar?')">Keluar</a>
        </div>
    </div>

    <div class="grid">
        <!-- FORM INPUT -->
        <div class="card">
            <h3>Form Pengajuan</h3>
            <form action="" method="POST">
                <div class="form-group">
                    <label>Nama Peminjam</label>
                    <input type="text" name="peminjam" required placeholder="Nama Lengkap">
                </div>
                <div class="form-group">
                    <label>Pilih Barang</label>
                    <select name="barang" required>
                        <option value="">-- Pilih --</option>
                        <option value="Laptop ASUS">Laptop ASUS</option>
                        <option value="Proyektor Epson">Proyektor Epson</option>
                        <option value="Kamera Canon">Kamera Canon</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jumlah</label>
                    <input type="number" name="jumlah" min="1" value="1" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Pinjam</label>
                    <input type="date" name="tglPinjam" required>
                </div>
                <button type="submit" name="submit_pinjam" class="btn-submit">Simpan Peminjaman</button>
            </form>
        </div>

        <!-- TABEL DATA -->
        <div class="card">
            <h3>Daftar & Status Peminjaman</h3>
            <table>
                <thead>
                    <tr>
                        <th>Peminjam</th>
                        <th>Barang</th>
                        <th>Jumlah</th>
                        <th>Tgl Pinjam</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($tampil_data)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['nama_peminjam']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_barang']); ?></td>
                        <td><?php echo $row['jumlah']; ?> Pcs</td>
                        <td><?php echo date('d-m-Y', strtotime($row['tgl_pinjam'])); ?></td>
                        <td><span class="badge"><?php echo $row['status']; ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if(mysqli_num_rows($tampil_data) == 0) : ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: #999;">Belum ada data peminjaman.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
